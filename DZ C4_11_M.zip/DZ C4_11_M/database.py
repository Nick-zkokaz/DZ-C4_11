import sqlalchemy as sa
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

DB_PATH = "sqlite:///tasks_db.sqlite3"
Base = declarative_base()

class TodoItem(Base):
    __tablename__ = 'tasks_db'

    id = sa.Column(sa.INTEGER, primary_key=True)
    description = sa.Column(sa.TEXT)
    is_completed = sa.Column(sa.BOOLEAN, default=False)
    

def connect_db():
    engine = sa.create_engine(DB_PATH)
    Base.metadata.create_all(engine)
    session = sessionmaker(engine)
    return session()




def json_db():
    session = connect_db()
    tasks = session.query(TodoItem).all()
    tasks_db = []
    
    for task in tasks:
        tasks_db.append({
            'description': task.description,
            'is_completed': task.is_completed,
            'uid': task.id,
        })
    return tasks_db
    


def create_task(description, is_completed):
    new_task = TodoItem(
        description = description,
        is_completed = is_completed,
        )
    session = connect_db()
    session.add(new_task)
    session.commit()



def delete_task(arg):
    session = connect_db()
    session.query(TodoItem).filter(TodoItem.id == arg).delete()
    session.commit()


def change_desc(uid, desc):
    session = connect_db()
    session.query(TodoItem.description).filter(TodoItem.id == uid).update({TodoItem.description: desc})
    session.commit()

def change_compl(uid, compl):
    session = connect_db()
    session.query(TodoItem.is_completed).filter(TodoItem.id == uid).update({TodoItem.is_completed: compl})
    session.commit()

