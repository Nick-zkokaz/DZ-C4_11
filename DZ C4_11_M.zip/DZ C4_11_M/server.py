import bottle


from truckpad.bottle.cors import CorsPlugin, enable_cors
from database import json_db, connect_db, create_task, delete_task, change_desc, change_compl

app = bottle.Bottle() 





@enable_cors
@app.route("/api/tasks/", method=["GET", "POST"])
def add_task():
    if bottle.request.method == 'GET':
        return {'tasks': json_db()}
    elif bottle.request.method == "POST":
        desc = bottle.request.json['description']
        is_completed = bottle.request.json.get('is_completed')
        if len(desc) > 0:
            if is_completed == None:
                create_task(desc, False)
            else:
                create_task(desc, True)
        return "OK"

@enable_cors
@app.route("/api/tasks/<uid:int>", method=["GET", "PUT", "DELETE"])
def show_or_modify_task(uid):
    if bottle.request.method == 'GET':
        return {'tasks': json_db()}
    elif bottle.request.method == "PUT":
        desc = bottle.request.json['description']
        is_completed = bottle.request.json.get('is_completed')
        if is_completed == None:
            change_compl(uid, False)
            change_desc(uid, desc)
        else:
            change_compl(uid, True)
            change_desc(uid, desc)
        return f"Modified task {uid}"
    elif bottle.request.method == "DELETE":
        bd = json_db()
        for uuid in bd:
            if (uuid['uid'] == uid) == False:
                return f'Not {uid} in bd'
                break
            else:
                delete_task(uid)
                return f'DELETED {uid}'
                break






app.install(CorsPlugin(origins=['http://localhost:8000'])) 

if __name__ == "__main__":
    bottle.run(app, host="localhost", port=5050) 
